import { PARTNERS } from '../shared/partners';
import { PROMOTIONS } from '../shared/promotions';
import { CAMPSITES } from '../shared/campsites';
import { COMMENTS } from '../shared/comments';


export const Partners = (state = PARTNERS, action) => {
    switch (action.type) {
        default:
          return state;
      }
};

export const Promotions = (state = PROMOTIONS, action) => {
    switch (action.type) {
        default:
          return state;
      }
};

export const Campsites = (state = CAMPSITES, action) => {
    switch (action.type) {
        default:
          return state;
      }
};

export const Comments = (state = COMMENTS, action) => {
    switch (action.type) {
        default:
          return state;
      }
};